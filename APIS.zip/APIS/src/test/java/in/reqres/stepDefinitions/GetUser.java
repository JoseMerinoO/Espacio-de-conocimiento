package in.reqres.stepDefinitions;

import in.reqres.tasks.users.GetuserTask;
import io.cucumber.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;

import static in.reqres.constans.Constans.URL_BASE_USER;

public class GetUser {

    @When("the user consumes the endpoint")
    public void theUserConsumesTehEndpoint() {
        Actor User=Actor.named("User")
                .whoCan(CallAnApi.at(URL_BASE_USER));
        User.attemptsTo(
                GetuserTask.calluser()

        );

    }
    @Then("the user will see the status code {int}")
    public void theUserWillSeeTheStatusCode(Integer int1) {

    }
}
