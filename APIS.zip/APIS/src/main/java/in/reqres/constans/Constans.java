package in.reqres.constans;

public class Constans {
    public static String URL_BASE_USER="https://reqres.in";
}
